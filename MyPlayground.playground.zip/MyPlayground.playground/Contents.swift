//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport
// this is to run tasks in background, it can be helpful for login request to save your login info without having to come  back and log again even though the network is connected
PlaygroundPage.current.needsIndefiniteExecution = true

let urlString = "http://quotes.rest/qod.json?category=inspire"
let url = URL(string: urlString)
let request = URLRequest(url: url!)
let session = URLSession.shared
let task = session.dataTask(with: request) { data, response, error in
    if error != nil { // Handle error
        return
    }
    print(String(data: data!, encoding: .utf8)!)
}
task.resume()

